package com.example.demo.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginCheck {
	
	String username;
	String password;
	
}
